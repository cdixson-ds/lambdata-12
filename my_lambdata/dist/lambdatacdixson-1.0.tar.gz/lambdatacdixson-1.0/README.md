# lambdata-12

##Installation

'''sh
cd path/to/lambdata-12
'''


Install package dependencies:
'''sh
pipenv install
'''

# Usage

An example script, contains a function to check nulls, a function to split a dataframe,
and exactly one knock knock joke. 

from my_lambdata.split import split
from my_lambdata.nulls import nulls
import my_lambdata.knock_knock 

'''sh
python my_lambdata/my_script.py
'''
